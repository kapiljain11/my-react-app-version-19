function Mygoal(props) {
  return <li>I am { props.goalprop }</li>;
}

function Mygoalresult() {
  const goals = ['Super', 'Great', 'Excelent'];
  return (
    <>
      <h1>Who has great goal?</h1>
      <ul>
        {goals.map((goal) => <Mygoal goalprop={goal} />)}
      </ul>
    </>
  );
}

export default Mygoalresult;