import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Routes, Route } from "react-router-dom";

//import components
import Car from './Car.js';
import Garage from './Garage.js';
import CarInfo from './CarInfo.js';
import Football from './Football.js';
import Goal from './Goal.js';
import Mygoalresult from './Mygoal.js';
import List from './List.js';
import MyForm from './MyForm.js';
import RegistrationForm from './Registration.js';
import MyColor from './MyColor.js';
import FavoriteColor from './FavoriteColor.js';
import Timer from './Timer.js';
import Counter from './Counter.js';
import FetchData from './FetchData.js';
import TodoMain from './TodoMain.js';
import Context from './Context.js';
import UseContext from './UseContext.js';
import Reducer from './Reducer.js';

import Layout from "./pages/Layout";
import Home from "./pages/Home";
import Blogs from "./pages/Blogs";
import Contact from "./pages/Contact";
import NoPage from "./pages/NoPage";


export default function Routing() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="blogs" element={<Blogs />} />
          <Route path="contact" element={<Contact />} />
          <Route path="*" element={<NoPage />} />
		  <Route path="car" element={<Car />} />
		  <Route path="carinfo" element={<CarInfo />} />
		  <Route path="football" element={<Football />} />
		  <Route path="goal" element={<Goal />} />
		  <Route path="list" element={<List />} />
		  <Route path="login" element={<MyForm />} />
		  <Route path="registration" element={<RegistrationForm />} />
		  <Route path="usestate" element={<MyColor />} />
		  <Route path="usestatenew" element={<FavoriteColor />} />
		  <Route path="timer" element={<Timer />} />
		  <Route path="counter" element={<Counter />} />
		  <Route path="userlist" element={<FetchData />} />
		  <Route path="todomain" element={<TodoMain />} />
		  <Route path="context" element={<Context />} />
		  <Route path="useContext" element={<UseContext />} />
		  <Route path="usereducer" element={<Reducer />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Routing />);

//const container = document.getElementById('root');
//const root = ReactDOM.createRoot(container);
//root.render(<p>Hello</p>);
//root.render(<FetchData />);


