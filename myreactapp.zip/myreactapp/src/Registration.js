import { useState } from 'react';
function RegistrationForm() {
  const [username, setUsername] = useState("");
  const [age, setAge] = useState("");
  const [comment, setComment] = useState("");
  const [country, setCountry] = useState("");
  const handleChangeUsername = (event) => {
    setUsername(event.target.value)
  }
  const handleChangeAge = (event) => {
    setAge(event.target.value)
  }
  const handleChangeComment = (event) => {
    setComment(event.target.value)
  }
  const handleChangeCountry = (event) => {
    setCountry(event.target.value)
  }
  const handleSubmit = (event) => {
    event.preventDefault();
    alert(`The name you entered was: ${username}`)
	alert(`The age you entered was: ${age}`)
	alert(`The comment you entered was: ${comment}`)
	alert(`The country you selected was: ${country}`)
  }
  return (
  <>
	<h1>Registration Form!</h1>
    <form onSubmit={handleSubmit}>	  
	  <table width="100%">
		  <tr>
			<td width="30%">Enter your name:</td>
			<td width="70%"><input name="username"  type="text" value={username} onChange={handleChangeUsername} /></td>
		  </tr>
		  <tr>
			<td width="30%">Enter your age:</td>
			<td width="70%"><input name="age"  type="number" value={age} onChange={handleChangeAge} /></td>
		  </tr>
		  <tr>
			<td width="30%">Comment:</td>
			<td width="70%"><textarea name="comment" value={comment} onChange={handleChangeComment} /></td>
		  </tr>
		  <tr>
			<td width="30%">Select your country:</td>
			<td width="70%">
			<select name="country" value={country} onChange={handleChangeCountry}>
				<option value="">Select</option>
				<option value="1">United State</option>
				<option value="2">India</option>
				<option value="3">Japan</option>
			</select>
			</td>
		  </tr>
		<tr><td colSpan="2"><input type="submit" /></td></tr>
	  </table>
    </form>
	<div id="display">
	<span>{username}&nbsp;{age}&nbsp;{comment}&nbsp;{country}</span>
	</div>
  </>
  )
}


export default RegistrationForm;