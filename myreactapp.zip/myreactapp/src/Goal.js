function MissedGoal() {
  return <h1>MISSED!</h1>;
}

function MadeGoal() {
  return <h1>Goal!</h1>;
}

function Goal() {	
  //const isGoal = props.isGoal;
  const isGoal = false;
  //ternery operator
  /*{ isGoal ? <MadeGoal/> : <MissedGoal/> }*/
  //if else condition 
  if (isGoal) {
    return <MadeGoal />;
  }else{
	  return <MissedGoal/>;
  }
}

export default Goal;