import { Outlet, Link } from "react-router-dom";

const Layout = () => {
  return (
    <>
      <nav>
        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/blogs">Blogs</Link>
          </li>
          <li>
            <Link to="/contact">Contact</Link>
          </li>
		  <li>
            <Link to="/car">JSX</Link>
          </li>
		  <li>
            <Link to="/carinfo">Prop</Link>
          </li>
		   <li>
            <Link to="/football">Event</Link>
          </li>
		   <li>
            <Link to="/goal">Condition</Link>
          </li>
		  <li>
            <Link to="/list">List</Link>
          </li>
		  <li>
            <Link to="/login">Login</Link>
          </li>
		  <li>
            <Link to="/registration">Registration</Link>
          </li>
		   <li>
            <Link to="/usestate">State</Link>
          </li>
		   <li>
            <Link to="/usestatenew">One State</Link>
          </li>
		  <li>
            <Link to="/timer">Use Effect</Link>
          </li>
		  <li>
            <Link to="/counter">Use Effect Other</Link>
          </li>
		   <li>
            <Link to="/userlist">User List</Link>
          </li>
		  <li>
            <Link to="/todomain">Memo</Link>
          </li>
		  <li>
            <Link to="/context">Context</Link>
          </li>
		  <li>
            <Link to="/usecontext">Context</Link>
          </li>
		  <li>
            <Link to="/usereducer">Reducer</Link>
          </li>
        </ul>
      </nav>

      <Outlet />
    </>
  )
};

export default Layout;