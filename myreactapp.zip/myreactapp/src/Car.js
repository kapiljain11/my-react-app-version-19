function Car() {
  /*const myElement = (
	  <div>
		<p className="myclass">I am a paragraph.</p>
		<p className="myclass">I am a paragraph too.</p>
	  </div>
  );*/
  const x = 8;

  let myElement = (
  <>
    <p className="myclass">I am a paragraph.</p>
    <p className="myclass">I am a paragraph too.</p>
  </>
);
  if(x>5){
	  myElement = (
  <>
    <p className="myclass">I am not a paragraph.</p>
    <p className="myclass">I am not a paragraph too.</p>
  </>
);
  }else{
	  myElement = (
  <>
    <p className="myclass">I am a paragraph.</p>
    <p className="myclass">I am a paragraph too.</p>
  </>
);
  }
  return( myElement );
}

export default Car;