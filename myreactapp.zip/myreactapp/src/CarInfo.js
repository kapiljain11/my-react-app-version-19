function CarInfo(props) {
  return <h2>Brand name is: { props.carinfo.name } and model is {props.carinfo.model}!</h2>;
}

function GarageInfo() {
  const carinformation = { name: "Ford", model: "Mustang" };
  return (
    <>
      <h1>Who lives in my Garage?</h1>
      <CarInfo carinfo={carinformation} />
    </>
  );
}
export default GarageInfo;
