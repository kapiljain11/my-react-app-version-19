import { useState } from 'react';
import styles from './css/mystyle.module.css'; 
import './css/Cssstyle.css';
import   './sass/my-sass.scss';
function MyForm() {
  const [name, setName] = useState("");
  const myStyle = {
    color: "white",
    backgroundColor: "DodgerBlue",
    padding: "10px",
    fontFamily: "Sans-Serif"
  };
  return (
    <form>
	  <h2 className="h1style">Login Form!</h2>
	  <h1 style={{color: "red",backgroundColor: "lightblue"}}>User Form!</h1>
	  <p style={myStyle}>User Form Details</p>
      <label className={styles.formlabel}>Enter your name:
        <input type="text"  value={name} onChange={(e) => setName(e.target.value)} />
      </label>
    </form>
  )
}


export default MyForm;